#!/system/bin/sh
# Mobile Signal Tweaks for Xtreme Boost v4.1 with 5G Support

MODE="$1"
SIGNAL="$2"  # ค่า dBm จาก service.sh
IS_5G="$3"   # รองรับ 5G หรือไม่
LOG="/data/xtremeboost/logs/status.log"

# ค่าเริ่มต้นถ้าสัญญาณตรวจไม่พบ
[ "$SIGNAL" = "N/A" ] || [ -z "$SIGNAL" ] && SIGNAL=-80

case "$MODE" in
    "refresh")
        if command -v svc >/dev/null 2>&1; then
            svc data disable
            sleep 1
            svc data enable
            echo "รีเฟรชข้อมูลมือถือสำเร็จ" >> "$LOG"
        else
            echo "คำสั่ง svc ไม่พบ ไม่สามารถรีเฟรชข้อมูลได้" >> "$LOG"
        fi
        ;;
    "gaming"|"performance")
        setprop persist.radio.lte_enabled 1
        [ "$IS_5G" = "true" ] && setprop ro.telephony.default_network 20 || setprop ro.telephony.default_network 9
        setprop persist.data.netmgrd.qos.enable 1
        setprop persist.radio.data_con_rprt 1
        setprop persist.radio.multisim.config dsds
        if [ "$SIGNAL" -lt -100 ]; then
            svc data disable
            sleep 1
            svc data enable
            echo "สัญญาณอ่อนมาก ($SIGNAL dBm) รีเฟรชโมเด็ม..." >> "$LOG"
        elif [ "$SIGNAL" -lt -90 ]; then
            setprop ril.ecclist 112,911
            echo "สัญญาณอ่อน ($SIGNAL dBm) ปรับแต่งโมเด็ม..." >> "$LOG"
        fi
        ;;
    "balanced")
        setprop persist.radio.lte_enabled 1
        [ "$IS_5G" = "true" ] && setprop ro.telephony.default_network 20 || setprop ro.telephony.default_network 9
        ;;
    "powersave")
        setprop persist.radio.lte_enabled 0
        setprop ro.telephony.default_network 0
        ;;
    "auto")
        if [ "$SIGNAL" -lt -100 ]; then
            setprop persist.radio.lte_enabled 1
            [ "$IS_5G" = "true" ] && setprop ro.telephony.default_network 20 || setprop ro.telephony.default_network 9
            svc data disable
            sleep 1
            svc data enable
            echo "สัญญาณอ่อนมาก ($SIGNAL dBm) บังคับใช้ 5G/LTE และรีเฟรช..." >> "$LOG"
        elif [ "$SIGNAL" -lt -90 ]; then
            setprop persist.radio.lte_enabled 1
            [ "$IS_5G" = "true" ] && setprop ro.telephony.default_network 20 || setprop ro.telephony.default_network 9
            echo "สัญญาณอ่อน ($SIGNAL dBm) บังคับใช้ 5G/LTE..." >> "$LOG"
        else
            setprop persist.radio.lte_enabled 1
            [ "$IS_5G" = "true" ] && setprop ro.telephony.default_network 20 || setprop ro.telephony.default_network 9
        fi
        ;;
    "custom")
        if [ -f "/data/xtremeboost/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && setprop "$key" "$value" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/xtremeboost/config/custom.conf"
        fi
        ;;
esac
