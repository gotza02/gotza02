#!/system/bin/sh
# Custom Mode Tweaks for Xtreme Boost v4.1

CUSTOM_CONFIG="/data/xtremeboost/config/custom.conf"
LOG="/data/xtremeboost/logs/status.log"

if [ -f "$CUSTOM_CONFIG" ]; then
    sh /data/adb/modules/xtremeboost/scripts/cpu_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/gpu_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/ram_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/net_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/mobile_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/cpu_memory_nodes_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/surface_flinger_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/vm_tuner.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/io_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/uclamp_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/hmp_exynos_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/cpu_power_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/thermal_tweaks.sh "custom"
    echo "นำการปรับแต่งแบบกำหนดเองจาก $CUSTOM_CONFIG ไปใช้" >> "$LOG"
else
    echo "ไม่พบไฟล์กำหนดค่าแบบกำหนดเอง!" >> "$LOG"
fi
