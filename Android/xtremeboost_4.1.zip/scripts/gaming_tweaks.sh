#!/system/bin/sh
# Gaming Mode Tweaks for Xtreme Boost v4.1

sh /data/adb/modules/xtremeboost/scripts/cpu_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/gpu_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/ram_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/net_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/cpu_memory_nodes_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/surface_flinger_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/vm_tuner.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/io_tweaks.sh "gaming"
