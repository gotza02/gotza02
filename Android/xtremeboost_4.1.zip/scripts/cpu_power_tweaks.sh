#!/system/bin/sh
# CPU Power Tweaks for Xtreme Boost v4.1

MODE="$1"
LOG="/data/xtremeboost/logs/status.log"

case "$MODE" in
    "gaming"|"performance")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/energy_aware" ] && echo 1 > "$cpu/energy_aware" 2>/dev/null || echo "$MODE: CPU power tweak ไม่รองรับสำหรับ $cpu" >> "$LOG"
        done
        ;;
    "balanced"|"powersave")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/energy_aware" ] && echo 0 > "$cpu/energy_aware" 2>/dev/null
        done
        ;;
    "custom")
        if [ -f "/data/xtremeboost/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/xtremeboost/config/custom.conf"
        fi
        ;;
esac
