#!/system/bin/sh
# CPU Tweaks for Xtreme Boost v4.1

MODE="$1"
CORES=$(nproc 2>/dev/null || echo "Unknown")
RAM=$(free -m | awk '/Mem:/ {print $2}' 2>/dev/null || echo 0)
CPU_USAGE=$(top -n 1 -b | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)
LOG="/data/xtremeboost/logs/status.log"

case "$MODE" in
    "gaming")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            if [ -f "$cpu/scaling_governor" ]; then
                echo "performance" > "$cpu/scaling_governor" 2>/dev/null || echo "Gaming: ไม่สามารถตั้งค่า governor สำหรับ $cpu" >> "$LOG"
            fi
            if [ -f "$cpu/scaling_available_frequencies" ]; then
                MAX_FREQ=$(cat "$cpu/scaling_available_frequencies" 2>/dev/null | awk '{print $NF}' || echo 0)
                [ "$MAX_FREQ" -ne 0 ] && echo "$MAX_FREQ" > "$cpu/scaling_max_freq" 2>/dev/null || echo "Gaming: ไม่สามารถตั้งค่าความถี่สูงสุดสำหรับ $cpu" >> "$LOG"
            fi
        done
        [ -f /proc/sys/kernel/sched_latency_ns ] && echo 1000000 > /proc/sys/kernel/sched_latency_ns 2>/dev/null
        [ -f /proc/sys/kernel/sched_min_granularity_ns ] && echo 100000 > /proc/sys/kernel/sched_min_granularity_ns 2>/dev/null
        [ -f /sys/module/cpu_boost/parameters/input_boost_ms ] && echo 50 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null
        [ -d /dev/stune ] && echo 1 > /dev/stune/top-app/schedtune.boost 2>/dev/null
        [ -f /proc/sys/kernel/sched_util_clamp_min ] && echo 1024 > /proc/sys/kernel/sched_util_clamp_min 2>/dev/null
        [ -f /sys/module/msm_thermal/parameters/enabled ] && echo 0 > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
        ;;
    "performance")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/scaling_governor" ] && echo "schedutil" > "$cpu/scaling_governor" 2>/dev/null || echo "Performance: ไม่สามารถตั้งค่า governor สำหรับ $cpu" >> "$LOG"
        done
        [ -f /sys/module/cpu_boost/parameters/input_boost_ms ] && echo 50 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null
        [ -f /proc/sys/kernel/sched_latency_ns ] && echo 750000 > /proc/sys/kernel/sched_latency_ns 2>/dev/null
        ;;
    "balanced")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/scaling_governor" ] && echo "schedutil" > "$cpu/scaling_governor" 2>/dev/null || echo "Balanced: ไม่สามารถตั้งค่า governor สำหรับ $cpu" >> "$LOG"
        done
        [ -f /proc/sys/kernel/sched_latency_ns ] && echo 500000 > /proc/sys/kernel/sched_latency_ns 2>/dev/null
        ;;
    "powersave")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            if [ -f "$cpu/scaling_governor" ]; then
                echo "powersave" > "$cpu/scaling_governor" 2>/dev/null || echo "Powersave: ไม่สามารถตั้งค่า governor สำหรับ $cpu" >> "$LOG"
            fi
            if [ -f "$cpu/scaling_available_frequencies" ]; then
                MIN_FREQ=$(cat "$cpu/scaling_available_frequencies" 2>/dev/null | awk '{print $1}' || echo 0)
                [ "$MIN_FREQ" -ne 0 ] && echo "$MIN_FREQ" > "$cpu/scaling_max_freq" 2>/dev/null || echo "Powersave: ไม่สามารถตั้งค่าความถี่ต่ำสุดสำหรับ $cpu" >> "$LOG"
            fi
        done
        [ -f /sys/module/msm_thermal/parameters/enabled ] && echo 1 > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
        ;;
    "custom")
        if [ -f "/data/xtremeboost/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/xtremeboost/config/custom.conf"
        fi
        ;;
esac
