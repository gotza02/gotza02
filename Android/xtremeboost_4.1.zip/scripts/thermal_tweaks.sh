#!/system/bin/sh
# Thermal Throttle Tweaks for Xtreme Boost v4.1

MODE="$1"
LOG="/data/xtremeboost/logs/status.log"

case "$MODE" in
    "throttle")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/scaling_governor" ] && echo "schedutil" > "$cpu/scaling_governor" 2>/dev/null || echo "Throttle: CPU governor ไม่รองรับสำหรับ $cpu" >> "$LOG"
            if [ -f "$cpu/scaling_available_frequencies" ]; then
                MID_FREQ=$(cat "$cpu/scaling_available_frequencies" 2>/dev/null | awk '{print $((NF/2))}' || echo 0)
                [ "$MID_FREQ" -ne 0 ] && echo "$MID_FREQ" > "$cpu/scaling_max_freq" 2>/dev/null || echo "Throttle: ไม่สามารถตั้งค่าความถี่กลางสำหรับ $cpu" >> "$LOG"
            fi
        done
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "simple_ondemand" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
        [ -f /sys/module/msm_thermal/parameters/enabled ] && echo 1 > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
        ;;
    "gaming"|"performance")
        [ -f /sys/module/msm_thermal/parameters/enabled ] && echo 0 > /sys/module/msm_thermal/parameters/enabled 2>/dev/null || echo "$MODE: Thermal tweak ไม่รองรับ" >> "$LOG"
        ;;
    "balanced"|"powersave")
        [ -f /sys/module/msm_thermal/parameters/enabled ] && echo 1 > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
        ;;
    "custom")
        if [ -f "/data/xtremeboost/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/xtremeboost/config/custom.conf"
        fi
        ;;
esac
