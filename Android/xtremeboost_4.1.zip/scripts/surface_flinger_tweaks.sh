#!/system/bin/sh
# Surface Flinger Multimode Tweaks for Xtreme Boost v4.1

MODE="$1"

case "$MODE" in
    "gaming")
        setprop debug.sf.latch_unsignaled 1
        setprop debug.sf.disable_backpressure 1
        setprop debug.sf.use_hwc2 1
        ;;
    "performance")
        setprop debug.sf.latch_unsignaled 1
        setprop debug.sf.use_hwc2 1
        ;;
    "balanced")
        setprop debug.sf.latch_unsignaled 0
        setprop debug.sf.use_hwc2 1
        ;;
    "powersave")
        setprop debug.sf.latch_unsignaled 0
        setprop debug.sf.disable_backpressure 0
        ;;
    "custom")
        if [ -f "/data/xtremeboost/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && setprop "$key" "$value" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/xtremeboost/config/custom.conf"
        fi
        ;;
esac
