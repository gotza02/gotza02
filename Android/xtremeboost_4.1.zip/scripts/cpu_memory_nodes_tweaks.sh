#!/system/bin/sh
# CPU Memory Nodes Tweaks for Xtreme Boost v4.1

MODE="$1"
NUMA_NODES=$(ls /sys/devices/system/node/ 2>/dev/null | grep -c "node[0-9]")
LOG="/data/xtremeboost/logs/status.log"

case "$MODE" in
    "gaming"|"performance")
        if [ "$NUMA_NODES" -gt 0 ]; then
            for node in /sys/devices/system/node/node*; do
                [ -f "$node/memlatency" ] && echo 0 > "$node/memlatency" 2>/dev/null || echo "NUMA memlatency ไม่รองรับ" >> "$LOG"
                [ -f "$node/membandwidth" ] && echo 100 > "$node/membandwidth" 2>/dev/null || echo "NUMA membandwidth ไม่รองรับ" >> "$LOG"
            done
        fi
        ;;
    "balanced")
        if [ "$NUMA_NODES" -gt 0 ]; then
            for node in /sys/devices/system/node/node*; do
                [ -f "$node/memlatency" ] && echo 50 > "$node/memlatency" 2>/dev/null
            done
        fi
        ;;
    "powersave")
        # ไม่ปรับแต่ง NUMA เพื่อประหยัดพลังงาน
        ;;
    "custom")
        if [ -f "/data/xtremeboost/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/xtremeboost/config/custom.conf"
        fi
        ;;
esac
