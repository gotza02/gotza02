#!/system/bin/sh
# Xtreme Boost Service Script v4.1

CONFIG="/data/xtremeboost/mode.conf"
CUSTOM_CONFIG="/data/xtremeboost/config/custom.conf"
GAMING_APPS="/data/xtremeboost/config/gaming_apps.conf"
LOG="/data/xtremeboost/logs/status.log"
PERF_LOG="/data/xtremeboost/logs/performance.log"
STATS="/data/xtremeboost/stats.conf"
ANDROID_VERSION=$(getprop ro.build.version.release 2>/dev/null || echo "Unknown")

# กำหนดโหมดเริ่มต้นถ้าไม่มี
[ ! -f "$CONFIG" ] && echo "balanced" > "$CONFIG"
MODE=$(cat "$CONFIG" 2>/dev/null || echo "balanced")

# ฟังก์ชันหาแอปที่ใช้งานอยู่
get_foreground_app() {
    APP=$(dumpsys window | grep mCurrentFocus | cut -d/ -f1 | cut -d. -f2 2>/dev/null)
    [ -z "$APP" ] && APP="unknown"
    echo "$APP"
}

# ฟังก์ชันตรวจสอบ 5G
check_5g_support() {
    NR_MODES=$(getprop ro.telephony.nr_modes 2>/dev/null)
    [ -n "$NR_MODES" ] && echo "$NR_MODES" | grep -q "5G" && echo "true" || echo "false"
}

# ฟังก์ชันตรวจจับ SoC
detect_soc() {
    SOC=$(getprop ro.board.platform 2>/dev/null || echo "unknown")
    case "$SOC" in
        "exynos"*) echo "exynos" ;;
        "snapdragon"|"sdm"*) echo "snapdragon" ;;
        "mt"*) echo "mediatek" ;;
        *) echo "unknown" ;;
    esac
}

# ฟังก์ชันตรวจสอบทรัพยากร
check_resources() {
    CORES=$(nproc 2>/dev/null || echo "Unknown")
    RAM=$(free -m | awk '/Mem:/ {print $2}' 2>/dev/null || echo 0)
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || echo 0)
    [ "$TEMP" -eq 0 ] && TEMP=$(cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | head -n 1 || echo 0)
    BATTERY=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo 50)
    CPU_USAGE=$(top -n 1 -b | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)
    [ "$CPU_USAGE" = 0 ] && CPU_USAGE=$(dumpsys cpuinfo | grep "TOTAL" | awk '{print $2}' | cut -d% -f1 2>/dev/null || echo 0)
    GPU_LOAD=$(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null | awk '{print $1}' || echo 0)
    SIGNAL=$(dumpsys telephony.registry | grep "mSignalStrength" | awk '{print $NF}' | tail -n 1 2>/dev/null || echo -80)
    IS_5G=$(check_5g_support)
    SOC=$(detect_soc)
    echo "Device: Android $ANDROID_VERSION, SoC: $SOC, Cores: $CORES, RAM: ${RAM}MB, Temp: $((TEMP/1000))°C, Battery: $BATTERY%, CPU: ${CPU_USAGE}%, GPU: ${GPU_LOAD}%, Signal: $SIGNAL dBm, 5G: $IS_5G" >> "$PERF_LOG"
}

# ฟังก์ชัน Overwatch
overwatch() {
    if [ "$CPU_USAGE" -gt 95 ] && [ "$TEMP" -gt 70000 ]; then
        echo "ตรวจพบ CPU ใช้งานสูงและอุณหภูมิสูงเกินไป ปรับใช้การควบคุมความร้อน" >> "$LOG"
        [ -f "/data/adb/modules/xtremeboost/scripts/thermal_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/thermal_tweaks.sh" "throttle" || echo "thermal_tweaks.sh ไม่พบ!" >> "$LOG"
    fi
}

# ฟังก์ชันกู้คืนระบบ
recover_system() {
    if [ "$TEMP" -gt 80000 ] || [ "$BATTERY" -lt 5 ]; then
        echo "ตรวจพบสถานะวิกฤต (อุณหภูมิ: $((TEMP/1000))°C, แบตเตอรี่: $BATTERY%)! เปลี่ยนเป็นโหมดประหยัดพลังงาน" >> "$LOG"
        [ -f "/data/adb/modules/xtremeboost/scripts/powersave_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/powersave_tweaks.sh" || echo "powersave_tweaks.sh ไม่พบ!" >> "$LOG"
        MODE="powersave"
    fi
}

# ฟังก์ชันแสดง Toast และ Notification
show_toast_and_notification() {
    MODE="$1"
    if [ "${ANDROID_VERSION%%.*}" -lt 10 ]; then
        am broadcast -a android.intent.action.SHOW_TOAST -e message "Xtreme Boost เริ่มทำงานในโหมด: $MODE" 2>/dev/null || echo "Toast ล้มเหลวใน Android $ANDROID_VERSION" >> "$LOG"
        am broadcast -a android.intent.action.SHOW_NOTIFICATION -e title "Xtreme Boost" -e message "เริ่มในโหมด $MODE" -e id 1001 2>/dev/null || echo "Notification ล้มเหลวใน Android $ANDROID_VERSION" >> "$LOG"
    else
        echo "ข้าม Toast/Notification ใน Android $ANDROID_VERSION เนื่องจากข้อจำกัด" >> "$LOG"
    fi
}

# เรียกใช้ฟังก์ชันหลัก
check_resources
APP=$(get_foreground_app)
echo "$APP $(date +%s)" >> "$STATS"

# ตรรกะโหมด Auto
if [ "$MODE" = "auto" ]; then
    if [ -f "$GAMING_APPS" ] && grep -q "^$APP$" "$GAMING_APPS"; then
        MODE="gaming"
    elif [ "$BATTERY" -lt 20 ] || [ "$TEMP" -gt 60000 ] || [ "$CPU_USAGE" -gt 90 ]; then
        MODE="powersave"
    elif [ "$RAM" -gt 4096 ] && [ "$BATTERY" -gt 80 ] && [ "$CPU_USAGE" -lt 50 ] && [ "$SIGNAL" -gt -85 ]; then
        MODE="performance"
    else
        MODE="balanced"
    fi
fi

# ปรับแต่งตามโหมด
case "$MODE" in
    "gaming")
        setprop debug.gr.swapinterval 1
        setprop ro.config.hw_quickpoweron true
        [ "$RAM" -lt 4096 ] && setprop dalvik.vm.heapsize 128m || setprop dalvik.vm.heapsize 512m
        [ -f "/data/adb/modules/xtremeboost/scripts/gaming_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/gaming_tweaks.sh" || echo "gaming_tweaks.sh ไม่พบ!" >> "$LOG"
        ;;
    "performance")
        setprop persist.sys.scrollingcache 3
        setprop ro.config.low_ram false
        [ "$RAM" -lt 2048 ] && setprop dalvik.vm.heapsize 96m || setprop dalvik.vm.heapsize 256m
        [ -f "/data/adb/modules/xtremeboost/scripts/performance_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/performance_tweaks.sh" || echo "performance_tweaks.sh ไม่พบ!" >> "$LOG"
        ;;
    "balanced")
        setprop persist.sys.scrollingcache 2
        setprop ro.config.low_ram false
        [ "$RAM" -lt 4096 ] && setprop dalvik.vm.heapsize 128m || setprop dalvik.vm.heapsize 256m
        [ -f "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh" || echo "balanced_tweaks.sh ไม่พบ!" >> "$LOG"
        ;;
    "powersave")
        setprop wifi.supplicant_scan_interval 180
        setprop ro.config.low_ram true
        setprop dalvik.vm.heapsize 64m
        setprop pm.sleep_mode 1
        [ -f "/data/adb/modules/xtremeboost/scripts/powersave_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/powersave_tweaks.sh" || echo "powersave_tweaks.sh ไม่พบ!" >> "$LOG"
        ;;
    "custom")
        if [ -f "$CUSTOM_CONFIG" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && setprop "$key" "$value"
            done < "$CUSTOM_CONFIG"
            [ -f "/data/adb/modules/xtremeboost/scripts/custom_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/custom_tweaks.sh" || echo "custom_tweaks.sh ไม่พบ!" >> "$LOG"
        else
            echo "ไม่พบไฟล์กำหนดค่าแบบกำหนดเอง ใช้โหมดสมดุลแทน" >> "$LOG"
            [ -f "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh" || echo "balanced_tweaks.sh ไม่พบ!" >> "$LOG"
            MODE="balanced"
        fi
        ;;
    *)
        echo "ตรวจพบโหมดไม่ถูกต้อง ใช้โหมดสมดุลแทน" >> "$LOG"
        setprop persist.sys.scrollingcache 2
        setprop ro.config.low_ram false
        [ -f "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh" || echo "balanced_tweaks.sh ไม่พบ!" >> "$LOG"
        MODE="balanced"
        ;;
esac

# เรียกใช้การปรับแต่งตาม SoC
SOC=$(detect_soc)
case "$SOC" in
    "exynos")
        [ -f "/data/adb/modules/xtremeboost/scripts/hmp_exynos_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/hmp_exynos_tweaks.sh" "$MODE" || echo "hmp_exynos_tweaks.sh ไม่พบ!" >> "$LOG"
        ;;
    "snapdragon")
        [ -f "/data/adb/modules/xtremeboost/scripts/uclamp_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/uclamp_tweaks.sh" "$MODE" || echo "uclamp_tweaks.sh ไม่พบ!" >> "$LOG"
        ;;
    "mediatek")
        [ -f "/data/adb/modules/xtremeboost/scripts/cpu_power_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/cpu_power_tweaks.sh" "$MODE" || echo "cpu_power_tweaks.sh ไม่พบ!" >> "$LOG"
        ;;
esac

# ปรับแต่งสัญญาณมือถือ
[ -f "/data/adb/modules/xtremeboost/scripts/mobile_tweaks.sh" ] && sh "/data/adb/modules/xtremeboost/scripts/mobile_tweaks.sh" "$MODE" "$SIGNAL" "$IS_5G" || echo "mobile_tweaks.sh ไม่พบ!" >> "$LOG"

# เรียกใช้ Overwatch และ Recover
overwatch
recover_system

# บันทึกสถานะ
echo "$MODE" > "$CONFIG"
echo "Xtreme Boost v4.1 เริ่มทำงานในโหมด $MODE ที่ $(date)" >> "$LOG"

# แสดง Toast และ Notification
show_toast_and_notification "$MODE"
