#!/system/bin/sh
# Xtreme Boost Install Script v4.1

# ตรวจสอบ Magisk
[ ! -d "/data/adb/modules" ] && { echo "Magisk ไม่พบ!"; exit 1; }

# สร้างโฟลเดอร์
mkdir -p /data/xtremeboost/logs
mkdir -p /data/xtremeboost/backup
mkdir -p /data/xtremeboost/config

# สำรอง build.prop
[ -f /system/build.prop ] && cp /system/build.prop /data/xtremeboost/backup/build.prop.bak 2>/dev/null || echo "ไม่สามารถสำรอง build.prop ได้" >&2

# สร้าง symlink
[ -w /system/bin ] || { echo "ไม่มีสิทธิ์เขียนใน /system/bin!"; exit 1; }
ln -sf /data/adb/modules/xtremeboost/common/optimize.sh /system/bin/optimize 2>/dev/null || { echo "ไม่สามารถสร้าง symlink ได้!"; exit 1; }
chmod 755 /system/bin/optimize

echo "Xtreme Boost v4.1 ติดตั้งสำเร็จ"
