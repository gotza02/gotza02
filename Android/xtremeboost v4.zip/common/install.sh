#!/system/bin/sh
# Xtreme Boost Install Script v4.0

# สร้างโฟลเดอร์
mkdir -p /data/xtremeboost/logs
mkdir -p /data/xtremeboost/backup
mkdir -p /data/xtremeboost/config

# ตรวจสอบ Magisk
[ ! -d "/data/adb/modules" ] && { echo "Magisk not detected!"; exit 1; }

# สำรอง build.prop
[ -f /system/build.prop ] && cp /system/build.prop /data/xtremeboost/backup/build.prop.bak

# สร้าง symlink
ln -sf /data/adb/modules/xtremeboost/common/optimize.sh /system/bin/optimize

echo "Xtreme Boost v4.0 installed successfully"
