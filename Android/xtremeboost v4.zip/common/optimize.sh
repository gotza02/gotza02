#!/system/bin/sh
# Xtreme Boost Optimizer v4.0

CONFIG="/data/xtremeboost/mode.conf"
LOG="/data/xtremeboost/logs/status.log"
PERF_LOG="/data/xtremeboost/logs/performance.log"
CUSTOM_CONFIG="/data/xtremeboost/config/custom.conf"

show_status() {
    CURRENT=$(cat "$CONFIG" 2>/dev/null || echo "Not set")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || echo 0)
    BATTERY=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "N/A")
    RAM=$(free -m | awk '/Mem:/ {print $2}')
    CORES=$(nproc)
    CPU_USAGE=$(top -n 1 | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)
    GPU_LOAD=$(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null | awk '{print $1}' || echo 0)
    SIGNAL=$(dumpsys telephony.registry | grep "mSignalStrength" | awk '{print $NF}' | tail -n 1 2>/dev/null || echo "N/A")
    IS_5G=$(getprop ro.telephony.nr_modes 2>/dev/null | grep -q "5G" && echo "Yes" || echo "No")
    echo "Current Mode: $CURRENT"
    echo "Temperature: $((TEMP/1000))°C"
    echo "Battery: $BATTERY%"
    echo "RAM: ${RAM}MB"
    echo "CPU Cores: $CORES (Usage: ${CPU_USAGE}%)"
    echo "GPU Load: ${GPU_LOAD}%"
    echo "Mobile Signal: $SIGNAL dBm (5G Support: $IS_5G)"
    echo "Last applied: $(tail -n 1 "$LOG" 2>/dev/null)"
}

apply_mode() {
    MODE="$1"
    case "$MODE" in
        "gaming"|"performance"|"balanced"|"powersave"|"auto"|"custom")
            sh "/data/adb/modules/xtremeboost/common/service.sh"
            echo "$MODE" > "$CONFIG"
            echo "Mode $MODE applied at $(date)" >> "$LOG"
            am broadcast -a android.intent.action.SHOW_TOAST -e message "Xtreme Boost: $MODE Activated"
            ;;
        *)
            echo "Invalid mode! Use: gaming, performance, balanced, powersave, auto, custom"
            exit 1
            ;;
    esac
}

refresh_signal() {
    sh "/data/adb/modules/xtremeboost/scripts/mobile_tweaks.sh" "refresh"
    echo "Mobile signal refreshed at $(date)" >> "$LOG"
}

log_performance() {
    CPU_USAGE=$(top -n 1 | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)
    RAM_FREE=$(free -m | awk '/Mem:/ {print $4}')
    BATTERY=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "N/A")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || echo 0)
    SIGNAL=$(dumpsys telephony.registry | grep "mSignalStrength" | awk '{print $NF}' | tail -n 1 2>/dev/null || echo "N/A")
    LATENCY=$(ping -c 5 8.8.8.8 | grep "rtt" | awk '{print $4}' | cut -d'/' -f2 2>/dev/null || echo "N/A")
    echo "Performance: CPU=${CPU_USAGE}%, RAM Free=${RAM_FREE}MB, Battery=${BATTERY}%, Temp=$((TEMP/1000))°C, Signal=${SIGNAL} dBm, Latency=${LATENCY}ms at $(date)" >> "$PERF_LOG"
    echo "Logged performance at $(date)" >> "$LOG"
}

if [ "$1" = "--status" ]; then
    show_status
elif [ "$1" = "--refresh-signal" ]; then
    refresh_signal
elif [ "$1" = "--log-performance" ]; then
    log_performance
elif [ -z "$1" ]; then
    echo "Xtreme Boost Optimizer v4.0"
    echo "Usage: optimize <mode> | --status | --refresh-signal | --log-performance"
    echo "Modes: gaming, performance, balanced, powersave, auto, custom"
    echo "Custom mode uses /data/xtremeboost/config/custom.conf"
    show_status
else
    apply_mode "$1"
fi
