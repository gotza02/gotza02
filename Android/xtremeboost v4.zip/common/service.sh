#!/system/bin/sh
# Xtreme Boost Service Script v4.0

CONFIG="/data/xtremeboost/mode.conf"
CUSTOM_CONFIG="/data/xtremeboost/config/custom.conf"
GAMING_APPS="/data/xtremeboost/config/gaming_apps.conf"
LOG="/data/xtremeboost/logs/status.log"
PERF_LOG="/data/xtremeboost/logs/performance.log"
STATS="/data/xtremeboost/stats.conf"

# กำหนดโหมดเริ่มต้น
[ ! -f "$CONFIG" ] && echo "balanced" > "$CONFIG"
MODE=$(cat "$CONFIG")

# ฟังก์ชันหาแอปที่ใช้งาน
get_foreground_app() {
    dumpsys window | grep mCurrentFocus | cut -d/ -f1 | cut -d. -f2 2>/dev/null || echo "unknown"
}

# ฟังก์ชันตรวจสอบ 5G
check_5g_support() {
    getprop ro.telephony.nr_modes 2>/dev/null | grep -q "5G" && echo "true" || echo "false"
}

# ฟังก์ชันตรวจสอบทรัพยากร
check_resources() {
    ANDROID_VERSION=$(getprop ro.build.version.release)
    CORES=$(nproc)
    RAM=$(free -m | awk '/Mem:/ {print $2}')
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || echo 0)
    BATTERY=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo 50)
    CPU_USAGE=$(top -n 1 | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)
    GPU_LOAD=$(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null | awk '{print $1}' || echo 0)
    SIGNAL=$(dumpsys telephony.registry | grep "mSignalStrength" | awk '{print $NF}' | tail -n 1 2>/dev/null || echo -80)
    IS_5G=$(check_5g_support)
    echo "Device: Android $ANDROID_VERSION, Cores: $CORES, RAM: ${RAM}MB, Temp: $((TEMP/1000))°C, Battery: $BATTERY%, CPU: ${CPU_USAGE}%, GPU: ${GPU_LOAD}%, Signal: $SIGNAL dBm, 5G: $IS_5G" >> "$PERF_LOG"
}

# ฟังก์ชันกู้คืนระบบ
recover_system() {
    if [ "$TEMP" -gt 80000 ] || [ "$BATTERY" -lt 5 ]; then
        echo "Critical state detected (Temp: $((TEMP/1000))°C, Battery: $BATTERY%)! Reverting to powersave mode" >> "$LOG"
        sh "/data/adb/modules/xtremeboost/scripts/powersave_tweaks.sh"
        MODE="powersave"
    fi
}

# ตรวจสอบทรัพยากร
check_resources

# หาแอปที่ใช้งานอยู่
APP=$(get_foreground_app)
echo "$APP $(date +%s)" >> "$STATS"

# ตรรกะโหมด Auto และ Gaming เฉพาะแอป
if [ "$MODE" = "auto" ]; then
    if [ -f "$GAMING_APPS" ] && grep -q "^$APP$" "$GAMING_APPS"; then
        MODE="gaming"
    elif [ "$BATTERY" -lt 20 ] || [ "$TEMP" -gt 60000 ] || [ "$CPU_USAGE" -gt 90 ]; then
        MODE="powersave"
    elif [ "$RAM" -gt 4096 ] && [ "$BATTERY" -gt 80 ] && [ "$CPU_USAGE" -lt 50 ]; then
        MODE="performance"
    else
        MODE="balanced"
    fi
fi

# ปรับแต่งตามโหมด
case "$MODE" in
    "gaming")
        setprop debug.gr.swapinterval 1
        setprop ro.config.hw_quickpoweron true
        [ "$RAM" -lt 4096 ] && setprop dalvik.vm.heapsize 128m || setprop dalvik.vm.heapsize 512m
        setprop ro.min_freq_0 $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq 2>/dev/null || echo 0)
        sh "/data/adb/modules/xtremeboost/scripts/gaming_tweaks.sh"
        ;;
    "performance")
        setprop persist.sys.scrollingcache 3
        setprop ro.config.low_ram false
        [ "$RAM" -lt 2048 ] && setprop dalvik.vm.heapsize 96m || setprop dalvik.vm.heapsize 256m
        sh "/data/adb/modules/xtremeboost/scripts/performance_tweaks.sh"
        ;;
    "balanced")
        setprop persist.sys.scrollingcache 2
        setprop ro.config.low_ram false
        [ "$RAM" -lt 4096 ] && setprop dalvik.vm.heapsize 128m || setprop dalvik.vm.heapsize 256m
        sh "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh"
        ;;
    "powersave")
        setprop wifi.supplicant_scan_interval 180
        setprop ro.config.low_ram true
        setprop dalvik.vm.heapsize 64m
        setprop pm.sleep_mode 1
        sh "/data/adb/modules/xtremeboost/scripts/powersave_tweaks.sh"
        ;;
    "custom")
        if [ -f "$CUSTOM_CONFIG" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && setprop "$key" "$value"
            done < "$CUSTOM_CONFIG"
            sh "/data/adb/modules/xtremeboost/scripts/custom_tweaks.sh"
        else
            echo "Custom config not found, defaulting to balanced" >> "$LOG"
            sh "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh"
            MODE="balanced"
        fi
        ;;
    *)
        echo "Invalid mode detected, defaulting to balanced" >> "$LOG"
        setprop persist.sys.scrollingcache 2
        setprop ro.config.low_ram false
        sh "/data/adb/modules/xtremeboost/scripts/balanced_tweaks.sh"
        MODE="balanced"
        ;;
esac

# ปรับแต่งสัญญาณมือถือ (รวม 5G)
sh "/data/adb/modules/xtremeboost/scripts/mobile_tweaks.sh" "$MODE" "$SIGNAL" "$IS_5G"

# ตรวจสอบและกู้คืนระบบ
recover_system

echo "$MODE" > "$CONFIG"
echo "Xtreme Boost v4.0 initialized in $MODE mode at $(date)" >> "$LOG"
