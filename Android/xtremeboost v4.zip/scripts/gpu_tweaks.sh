#!/system/bin/sh
# GPU Tweaks for Xtreme Boost v4.0

MODE="$1"
GPU_LOAD=$(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null | awk '{print $1}' || echo 0)

case "$MODE" in
    "gaming")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
        MAX_FREQ=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies 2>/dev/null | awk '{print $NF}' || echo 0)
        [ -n "$MAX_FREQ" ] && echo "$MAX_FREQ" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
        ;;
    "performance")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
        ;;
    "balanced")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "simple_ondemand" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
        ;;
    "powersave")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "powersave" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
        MIN_FREQ=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies 2>/dev/null | awk '{print $1}' || echo 0)
        [ -n "$MIN_FREQ" ] && echo "$MIN_FREQ" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
        ;;
    "custom")
        # อ่านจาก custom.conf ถ้ามี
        ;;
esac
