#!/system/bin/sh
# Network Tweaks for Xtreme Boost v4.0

MODE="$1"
RAM=$(free -m | awk '/Mem:/ {print $2}')
IS_5G="$3"  # จาก service.sh

case "$MODE" in
    "gaming")
        echo "bbr" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo 1 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null
        sysctl -w net.core.rmem_max=26214400 2>/dev/null
        sysctl -w net.core.wmem_max=26214400 2>/dev/null
        setprop net.dns1 8.8.8.8
        setprop net.dns2 8.8.4.4
        ;;
    "performance")
        echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        sysctl -w net.core.rmem_max=1048576 2>/dev/null
        sysctl -w net.core.wmem_max=1048576 2>/dev/null
        setprop net.dns1 1.1.1.1
        setprop net.dns2 1.0.0.1
        ;;
    "balanced")
        echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        sysctl -w net.core.rmem_max=524288 2>/dev/null
        sysctl -w net.core.wmem_max=524288 2>/dev/null
        ;;
    "powersave")
        echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo 0 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null
        sysctl -w net.core.rmem_max=262144 2>/dev/null
        sysctl -w net.core.wmem_max=262144 2>/dev/null
        ;;
    "custom")
        # อ่านจาก custom.conf ถ้ามี
        ;;
esac
