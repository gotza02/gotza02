#!/system/bin/sh
# Custom Mode Tweaks for Xtreme Boost v4.0

CUSTOM_CONFIG="/data/xtremeboost/config/custom.conf"
LOG="/data/xtremeboost/logs/status.log"

if [ -f "$CUSTOM_CONFIG" ]; then
    sh /data/adb/modules/xtremeboost/scripts/cpu_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/gpu_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/ram_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/net_tweaks.sh "custom"
    sh /data/adb/modules/xtremeboost/scripts/mobile_tweaks.sh "custom"
    echo "Applied custom tweaks from $CUSTOM_CONFIG" >> "$LOG"
else
    echo "No custom config found!" >> "$LOG"
fi
