#!/system/bin/sh
# RAM Tweaks for Xtreme Boost v4.0

MODE="$1"
RAM=$(free -m | awk '/Mem:/ {print $2}')
RAM_FREE=$(free -m | awk '/Mem:/ {print $4}')

case "$MODE" in
    "gaming")
        sysctl -w vm.swappiness=0
        sysctl -w vm.vfs_cache_pressure=10
        echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*32)),$((RAM*64)),$((RAM*96))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
        swapoff /dev/block/zram0 2>/dev/null
        echo 0 > /sys/block/zram0/disksize 2>/dev/null
        ;;
    "performance")
        sysctl -w vm.swappiness=10
        sysctl -w vm.vfs_cache_pressure=50
        echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*36)),$((RAM*55)),$((RAM*73))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
        ;;
    "balanced")
        sysctl -w vm.swappiness=20
        sysctl -w vm.vfs_cache_pressure=75
        echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*36)),$((RAM*46)),$((RAM*64))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
        [ "$RAM" -lt 4096 ] && echo $((RAM*256*1024)) > /sys/block/zram0/disksize || echo $((RAM*512*1024)) > /sys/block/zram0/disksize 2>/dev/null
        mkswap /dev/block/zram0 2>/dev/null
        swapon /dev/block/zram0 2>/dev/null
        ;;
    "powersave")
        sysctl -w vm.swappiness=60
        sysctl -w vm.vfs_cache_pressure=100
        echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*32)),$((RAM*64)),$((RAM*96))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
        ;;
    "custom")
        # อ่านจาก custom.conf ถ้ามี
        ;;
esac
