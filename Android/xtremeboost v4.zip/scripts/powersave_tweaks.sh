#!/system/bin/sh
# Powersave Mode Tweaks for Xtreme Boost v4.0

sh /data/adb/modules/xtremeboost/scripts/cpu_tweaks.sh "powersave"
sh /data/adb/modules/xtremeboost/scripts/gpu_tweaks.sh "powersave"
sh /data/adb/modules/xtremeboost/scripts/ram_tweaks.sh "powersave"
sh /data/adb/modules/xtremeboost/scripts/net_tweaks.sh "powersave"
