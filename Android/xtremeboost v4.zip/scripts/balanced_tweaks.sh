#!/system/bin/sh
# Balanced Mode Tweaks for Xtreme Boost v4.0

sh /data/adb/modules/xtremeboost/scripts/cpu_tweaks.sh "balanced"
sh /data/adb/modules/xtremeboost/scripts/gpu_tweaks.sh "balanced"
sh /data/adb/modules/xtremeboost/scripts/ram_tweaks.sh "balanced"
sh /data/adb/modules/xtremeboost/scripts/net_tweaks.sh "balanced"
