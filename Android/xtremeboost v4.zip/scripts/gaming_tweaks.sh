#!/system/bin/sh
# Gaming Mode Tweaks for Xtreme Boost v4.0

sh /data/adb/modules/xtremeboost/scripts/cpu_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/gpu_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/ram_tweaks.sh "gaming"
sh /data/adb/modules/xtremeboost/scripts/net_tweaks.sh "gaming"
