#!/system/bin/sh
# CPU Tweaks for Xtreme Boost v4.0

MODE="$1"
CORES=$(nproc)
RAM=$(free -m | awk '/Mem:/ {print $2}')
CPU_USAGE=$(top -n 1 | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)

case "$MODE" in
    "gaming")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/scaling_governor" ] && echo "performance" > "$cpu/scaling_governor"
            MAX_FREQ=$(cat "$cpu/scaling_available_frequencies" 2>/dev/null | awk '{print $NF}' || echo 0)
            [ -n "$MAX_FREQ" ] && echo "$MAX_FREQ" > "$cpu/scaling_max_freq"
        done
        echo 1000000 > /proc/sys/kernel/sched_latency_ns 2>/dev/null
        echo 100000 > /proc/sys/kernel/sched_min_granularity_ns 2>/dev/null
        [ -f /sys/module/msm_thermal/parameters/enabled ] && echo 0 > /sys/module/msm_thermal/parameters/enabled
        ;;
    "performance")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/scaling_governor" ] && echo "schedutil" > "$cpu/scaling_governor"
        done
        echo 50 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null
        echo 750000 > /proc/sys/kernel/sched_latency_ns 2>/dev/null
        ;;
    "balanced")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/scaling_governor" ] && echo "schedutil" > "$cpu/scaling_governor"
        done
        echo 500000 > /proc/sys/kernel/sched_latency_ns 2>/dev/null
        ;;
    "powersave")
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
            [ -f "$cpu/scaling_governor" ] && echo "powersave" > "$cpu/scaling_governor"
            MIN_FREQ=$(cat "$cpu/scaling_available_frequencies" 2>/dev/null | awk '{print $1}' || echo 0)
            [ -n "$MIN_FREQ" ] && echo "$MIN_FREQ" > "$cpu/scaling_max_freq"
        done
        [ -f /sys/module/msm_thermal/parameters/enabled ] && echo 1 > /sys/module/msm_thermal/parameters/enabled
        ;;
    "custom")
        # อ่านจาก custom.conf ถ้ามี
        ;;
esac
