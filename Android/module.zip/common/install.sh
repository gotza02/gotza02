#!/system/bin/sh
[ ! -d "/data/adb/modules" ] && { echo "Magisk ไม่พบ!"; exit 1; }

mkdir -p /data/gtmodifyplusv1/logs
mkdir -p /data/gtmodifyplusv1/backup
mkdir -p /data/gtmodifyplusv1/config

[ -f /system/build.prop ] && cp /system/build.prop /data/gtmodifyplusv1/backup/build.prop.bak 2>/dev/null || echo "ไม่สามารถสำรอง build.prop ได้" >&2

[ -w /system/bin ] || mount -o remount,rw /system
ln -sf /data/adb/modules/gtmodifyplusv1/common/optimize.sh /system/bin/optimize 2>/dev/null || { echo "ไม่สามารถสร้าง symlink ได้!"; exit 1; }
chmod 755 /system/bin/optimize

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

echo "GT Modify Plus V1 ติดตั้งสำเร็จ"
