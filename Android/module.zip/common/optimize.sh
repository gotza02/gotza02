#!/system/bin/sh
CONFIG="/data/gtmodifyplusv1/mode.conf"
LOG="/data/gtmodifyplusv1/logs/status.log"
PERF_LOG="/data/gtmodifyplusv1/logs/performance.log"
CUSTOM_CONFIG="/data/gtmodifyplusv1/config/custom.conf"

[ ! -d "/data/adb/modules/gtmodifyplusv1" ] && { echo "โมดูล GT Modify Plus V1 ไม่ได้ติดตั้ง!"; exit 1; }

show_status() {
    CURRENT=$(cat "$CONFIG" 2>/dev/null || echo "ยังไม่ได้ตั้งค่า")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || echo 0)
    BATTERY=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "N/A")
    RAM=$(free -m | awk '/Mem:/ {print $2}' 2>/dev/null || echo 0)
    CORES=$(nproc 2>/dev/null || echo "ไม่ทราบ")
    CPU_USAGE=$(top -n 1 -b | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)
    GPU_LOAD=$(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null | awk '{print $1}' || echo 0)
    SIGNAL=$(dumpsys telephony.registry | grep "mSignalStrength" | awk '{print $NF}' | tail -n 1 2>/dev/null || echo "N/A")
    IS_5G=$(getprop ro.telephony.nr_modes 2>/dev/null | grep -q "5G" && echo "ใช่" || echo "ไม่")
    SOC=$(getprop ro.board.platform 2>/dev/null || echo "ไม่ทราบ")
    echo "=== สถานะ GT Modify Plus V1 ===" >> "$LOG"
    echo "โหมดปัจจุบัน: $CURRENT" >> "$LOG"
    echo "SoC: $SOC" >> "$LOG"
    echo "อุณหภูมิ: $((TEMP/1000))°C" >> "$LOG"
    echo "แบตเตอรี่: $BATTERY%" >> "$LOG"
    echo "RAM: ${RAM}MB" >> "$LOG"
    echo "CPU: $CORES คอร์ (ใช้งาน: ${CPU_USAGE}%)" >> "$LOG"
    echo "โหลด GPU: ${GPU_LOAD}%" >> "$LOG"
    echo "สัญญาณ: $SIGNAL dBm (รองรับ 5G: $IS_5G)" >> "$LOG"
    echo "อัปเดตล่าสุด: $(tail -n 1 "$LOG" 2>/dev/null)" >> "$LOG"
}

apply_mode() {
    MODE="$1"
    case "$MODE" in
        "gaming"|"performance"|"balanced"|"powersave"|"auto"|"custom")
            [ -f "/data/adb/modules/gtmodifyplusv1/common/service.sh" ] && sh "/data/adb/modules/gtmodifyplusv1/common/service.sh" || { echo "service.sh ไม่พบ!" >> "$LOG"; exit 1; }
            echo "$MODE" > "$CONFIG"
            echo "โหมด $MODE ถูกนำไปใช้ที่ $(date)" >> "$LOG"
            am broadcast -a android.intent.action.SHOW_TOAST -e message "GT Modify Plus V1: $MODE เปิดใช้งาน" 2>/dev/null || echo "Toast ล้มเหลว" >> "$LOG"
            ;;
        *)
            echo "โหมดไม่ถูกต้อง! ใช้: gaming, performance, balanced, powersave, auto, custom" >> "$LOG"
            exit 1
            ;;
    esac
}

refresh_signal() {
    [ -f "/data/adb/modules/gtmodifyplusv1/scripts/mobile_tweaks.sh" ] && sh "/data/adb/modules/gtmodifyplusv1/scripts/mobile_tweaks.sh" "refresh" || echo "mobile_tweaks.sh ไม่พบ!" >> "$LOG"
    echo "รีเฟรชสัญญาณมือถือที่ $(date)" >> "$LOG"
}

log_performance() {
    CPU_USAGE=$(top -n 1 -b | grep '%Cpu' | awk '{print $2}' | cut -d. -f1 2>/dev/null || echo 0)
    RAM_FREE=$(free -m | awk '/Mem:/ {print $4}' 2>/dev/null || echo 0)
    BATTERY=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "N/A")
    TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || echo 0)
    SIGNAL=$(dumpsys telephony.registry | grep "mSignalStrength" | awk '{print $NF}' | tail -n 1 2>/dev/null || echo "N/A")
    LATENCY=$(ping -c 5 8.8.8.8 | grep "rtt" | awk '{print $4}' | cut -d'/' -f2 2>/dev/null || echo "N/A")
    echo "ประสิทธิภาพ: CPU=${CPU_USAGE}%, RAM ว่าง=${RAM_FREE}MB, แบตเตอรี่=${BATTERY}%, อุณหภูมิ=$((TEMP/1000))°C, สัญญาณ=${SIGNAL} dBm, Latency=${LATENCY}ms ที่ $(date)" >> "$PERF_LOG"
    echo "บันทึกประสิทธิภาพที่ $(date)" >> "$LOG"
}

if [ "$1" = "--status" ]; then
    show_status
elif [ "$1" = "--refresh-signal" ]; then
    refresh_signal
elif [ "$1" = "--log-performance" ]; then
    log_performance
elif [ -z "$1" ]; then
    echo "GT Modify Plus V1 Optimizer" >> "$LOG"
    echo "การใช้งาน: optimize <mode> | --status | --refresh-signal | --log-performance" >> "$LOG"
    echo "โหมด: gaming, performance, balanced, powersave, auto, custom" >> "$LOG"
    echo "โหมดกำหนดเองใช้ /data/gtmodifyplusv1/config/custom.conf" >> "$LOG"
    show_status
else
    apply_mode "$1"
fi
