#!/system/bin/sh
MODE="$1"
RAM=$(free -m | awk '/Mem:/ {print $2}' 2>/dev/null || echo 0)
IS_5G="$3"
LOG="/data/gtmodifyplusv1/logs/status.log"

case "$MODE" in
    "gaming")
        [ -f /proc/sys/net/ipv4/tcp_congestion_control ] && echo "bbr" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null || echo "Gaming: TCP tweak ไม่รองรับ" >> "$LOG"
        [ -f /proc/sys/net/ipv4/tcp_low_latency ] && echo 1 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null
        sysctl -w net.core.rmem_max=26214400 2>/dev/null
        sysctl -w net.core.wmem_max=26214400 2>/dev/null
        setprop net.dns1 8.8.8.8
        setprop net.dns2 8.8.4.4
        ;;
    "performance")
        [ -f /proc/sys/net/ipv4/tcp_congestion_control ] && echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null || echo "Performance: TCP tweak ไม่รองรับ" >> "$LOG"
        sysctl -w net.core.rmem_max=1048576 2>/dev/null
        sysctl -w net.core.wmem_max=1048576 2>/dev/null
        setprop net.dns1 1.1.1.1
        setprop net.dns2 1.0.0.1
        ;;
    "balanced")
        [ -f /proc/sys/net/ipv4/tcp_congestion_control ] && echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null || echo "Balanced: TCP tweak ไม่รองรับ" >> "$LOG"
        sysctl -w net.core.rmem_max=524288 2>/dev/null
        sysctl -w net.core.wmem_max=524288 2>/dev/null
        ;;
    "powersave")
        [ -f /proc/sys/net/ipv4/tcp_congestion_control ] && echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null || echo "Powersave: TCP tweak ไม่รองรับ" >> "$LOG"
        [ -f /proc/sys/net/ipv4/tcp_low_latency ] && echo 0 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null
        sysctl -w net.core.rmem_max=262144 2>/dev/null
        sysctl -w net.core.wmem_max=262144 2>/dev/null
        ;;
    "custom")
        if [ -f "/data/gtmodifyplusv1/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/gtmodifyplusv1/config/custom.conf"
        fi
        ;;
esac
