#!/system/bin/sh
MODE="$1"
GPU_LOAD=$(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null | awk '{print $1}' || echo 0)
LOG="/data/gtmodifyplusv1/logs/status.log"

case "$MODE" in
    "gaming")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null || echo "Gaming: GPU governor ไม่รองรับ" >> "$LOG"
        if [ -f /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies ]; then
            MAX_FREQ=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies 2>/dev/null | awk '{print $NF}' || echo 0)
            [ "$MAX_FREQ" -ne 0 ] && echo "$MAX_FREQ" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null || echo "Gaming: ไม่สามารถตั้งค่าความถี่สูงสุด GPU" >> "$LOG"
        fi
        ;;
    "performance")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null || echo "Performance: GPU governor ไม่รองรับ" >> "$LOG"
        ;;
    "balanced")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "simple_ondemand" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null || echo "Balanced: GPU governor ไม่รองรับ" >> "$LOG"
        ;;
    "powersave")
        [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "powersave" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null || echo "Powersave: GPU governor ไม่รองรับ" >> "$LOG"
        if [ -f /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies ]; then
            MIN_FREQ=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies 2>/dev/null | awk '{print $1}' || echo 0)
            [ "$MIN_FREQ" -ne 0 ] && echo "$MIN_FREQ" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null || echo "Powersave: ไม่สามารถตั้งค่าความถี่ต่ำสุด GPU" >> "$LOG"
        fi
        ;;
    "custom")
        if [ -f "/data/gtmodifyplusv1/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/gtmodifyplusv1/config/custom.conf"
        fi
        ;;
esac
