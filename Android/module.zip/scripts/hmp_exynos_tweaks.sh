#!/system/bin/sh
MODE="$1"
LOG="/data/gtmodifyplusv1/logs/status.log"

case "$MODE" in
    "gaming")
        [ -f /sys/kernel/hmp/up_threshold ] && echo 800 > /sys/kernel/hmp/up_threshold 2>/dev/null || echo "Gaming: HMP up threshold ไม่รองรับ" >> "$LOG"
        [ -f /sys/kernel/hmp/down_threshold ] && echo 200 > /sys/kernel/hmp/down_threshold 2>/dev/null || echo "Gaming: HMP down threshold ไม่รองรับ" >> "$LOG"
        ;;
    "performance")
        [ -f /sys/kernel/hmp/up_threshold ] && echo 700 > /sys/kernel/hmp/up_threshold 2>/dev/null
        [ -f /sys/kernel/hmp/down_threshold ] && echo 300 > /sys/kernel/hmp/down_threshold 2>/dev/null
        ;;
    "balanced")
        [ -f /sys/kernel/hmp/up_threshold ] && echo 600 > /sys/kernel/hmp/up_threshold 2>/dev/null
        [ -f /sys/kernel/hmp/down_threshold ] && echo 400 > /sys/kernel/hmp/down_threshold 2>/dev/null
        ;;
    "powersave")
        [ -f /sys/kernel/hmp/up_threshold ] && echo 400 > /sys/kernel/hmp/up_threshold 2>/dev/null
        [ -f /sys/kernel/hmp/down_threshold ] && echo 500 > /sys/kernel/hmp/down_threshold 2>/dev/null
        ;;
    "custom")
        if [ -f "/data/gtmodifyplusv1/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/gtmodifyplusv1/config/custom.conf"
        fi
        ;;
esac
