#!/system/bin/sh
sh /data/adb/modules/gtmodifyplusv1/scripts/cpu_tweaks.sh "balanced"
sh /data/adb/modules/gtmodifyplusv1/scripts/gpu_tweaks.sh "balanced"
sh /data/adb/modules/gtmodifyplusv1/scripts/ram_tweaks.sh "balanced"
sh /data/adb/modules/gtmodifyplusv1/scripts/net_tweaks.sh "balanced"
sh /data/adb/modules/gtmodifyplusv1/scripts/cpu_memory_nodes_tweaks.sh "balanced"
sh /data/adb/modules/gtmodifyplusv1/scripts/surface_flinger_tweaks.sh "balanced"
sh /data/adb/modules/gtmodifyplusv1/scripts/vm_tuner.sh "balanced"
sh /data/adb/modules/gtmodifyplusv1/scripts/io_tweaks.sh "balanced"
