#!/system/bin/sh
MODE="$1"
LOG="/data/gtmodifyplusv1/logs/status.log"

case "$MODE" in
    "gaming")
        [ -f /sys/block/mmcblk0/queue/scheduler ] && echo "deadline" > /sys/block/mmcblk0/queue/scheduler 2>/dev/null || echo "Gaming: IO scheduler ไม่รองรับ" >> "$LOG"
        [ -f /sys/block/mmcblk0/queue/read_ahead_kb ] && echo 1024 > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null
        ;;
    "performance")
        [ -f /sys/block/mmcblk0/queue/scheduler ] && echo "cfq" > /sys/block/mmcblk0/queue/scheduler 2>/dev/null || echo "Performance: IO scheduler ไม่รองรับ" >> "$LOG"
        [ -f /sys/block/mmcblk0/queue/read_ahead_kb ] && echo 512 > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null
        ;;
    "balanced")
        [ -f /sys/block/mmcblk0/queue/scheduler ] && echo "bfq" > /sys/block/mmcblk0/queue/scheduler 2>/dev/null || echo "Balanced: IO scheduler ไม่รองรับ" >> "$LOG"
        [ -f /sys/block/mmcblk0/queue/read_ahead_kb ] && echo 256 > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null
        ;;
    "powersave")
        [ -f /sys/block/mmcblk0/queue/scheduler ] && echo "noop" > /sys/block/mmcblk0/queue/scheduler 2>/dev/null || echo "Powersave: IO scheduler ไม่รองรับ" >> "$LOG"
        [ -f /sys/block/mmcblk0/queue/read_ahead_kb ] && echo 128 > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null
        ;;
    "custom")
        if [ -f "/data/gtmodifyplusv1/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/gtmodifyplusv1/config/custom.conf"
        fi
        ;;
esac
