#!/system/bin/sh
MODE="$1"
LOG="/data/gtmodifyplusv1/logs/status.log"

case "$MODE" in
    "gaming")
        [ -f /sys/module/cpu_boost/parameters/input_boost_ms ] && echo 50 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null || echo "Gaming: CPU boost ไม่รองรับ" >> "$LOG"
        [ -d /dev/stune ] && echo 1 > /dev/stune/top-app/schedtune.boost 2>/dev/null || echo "Gaming: Schedtune ไม่รองรับ" >> "$LOG"
        [ -f /proc/sys/kernel/sched_util_clamp_min ] && echo 1024 > /proc/sys/kernel/sched_util_clamp_min 2>/dev/null || echo "Gaming: Uclamp ไม่รองรับ" >> "$LOG"
        ;;
    "performance")
        [ -f /sys/module/cpu_boost/parameters/input_boost_ms ] && echo 40 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null
        [ -d /dev/stune ] && echo 0 > /dev/stune/top-app/schedtune.boost 2>/dev/null
        ;;
    "balanced")
        [ -f /sys/module/cpu_boost/parameters/input_boost_ms ] && echo 20 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null
        ;;
    "powersave")
        [ -f /sys/module/cpu_boost/parameters/input_boost_ms ] && echo 0 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null
        [ -d /dev/stune ] && echo -1 > /dev/stune/top-app/schedtune.boost 2>/dev/null
        ;;
    "custom")
        if [ -f "/data/gtmodifyplusv1/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/gtmodifyplusv1/config/custom.conf"
        fi
        ;;
esac
