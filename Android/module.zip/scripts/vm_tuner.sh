#!/system/bin/sh
MODE="$1"
SELINUX=$(getenforce 2>/dev/null || echo "Unknown")
KERNEL_VERSION=$(uname -r | cut -d'.' -f1-2)
LOG="/data/gtmodifyplusv1/logs/status.log"

case "$MODE" in
    "gaming")
        sysctl -w vm.dirty_ratio=20 2>/dev/null || echo "Gaming: ไม่สามารถตั้งค่า dirty_ratio" >> "$LOG"
        sysctl -w vm.dirty_background_ratio=5 2>/dev/null || echo "Gaming: ไม่สามารถตั้งค่า dirty_background_ratio" >> "$LOG"
        [ "$SELINUX" = "Enforcing" ] && echo "ตรวจพบเคอร์เนลจำกัด ข้ามการปรับแต่ง VM ขั้นสูง" >> "$LOG" || sysctl -w vm.overcommit_memory=1 2>/dev/null
        ;;
    "performance")
        sysctl -w vm.dirty_ratio=15 2>/dev/null || echo "Performance: ไม่สามารถตั้งค่า dirty_ratio" >> "$LOG"
        sysctl -w vm.dirty_background_ratio=10 2>/dev/null || echo "Performance: ไม่สามารถตั้งค่า dirty_background_ratio" >> "$LOG"
        ;;
    "balanced")
        sysctl -w vm.dirty_ratio=10 2>/dev/null || echo "Balanced: ไม่สามารถตั้งค่า dirty_ratio" >> "$LOG"
        sysctl -w vm.dirty_background_ratio=5 2>/dev/null || echo "Balanced: ไม่สามารถตั้งค่า dirty_background_ratio" >> "$LOG"
        ;;
    "powersave")
        sysctl -w vm.dirty_ratio=5 2>/dev/null || echo "Powersave: ไม่สามารถตั้งค่า dirty_ratio" >> "$LOG"
        sysctl -w vm.dirty_background_ratio=2 2>/dev/null || echo "Powersave: ไม่สามารถตั้งค่า dirty_background_ratio" >> "$LOG"
        ;;
    "custom")
        if [ -f "/data/gtmodifyplusv1/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && sysctl -w "$key=$value" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/gtmodifyplusv1/config/custom.conf"
        fi
        ;;
esac
