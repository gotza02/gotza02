#!/system/bin/sh
MODE="$1"
RAM=$(free -m | awk '/Mem:/ {print $2}' 2>/dev/null || echo 0)
RAM_FREE=$(free -m | awk '/Mem:/ {print $4}' 2>/dev/null || echo 0)
NUMA_NODES=$(ls /sys/devices/system/node/ 2>/dev/null | grep -c "node[0-9]")
LOG="/data/gtmodifyplusv1/logs/status.log"

case "$MODE" in
    "gaming")
        sysctl -w vm.swappiness=0 2>/dev/null || echo "Gaming: ไม่สามารถตั้งค่า swappiness" >> "$LOG"
        sysctl -w vm.vfs_cache_pressure=10 2>/dev/null || echo "Gaming: ไม่สามารถตั้งค่า vfs_cache_pressure" >> "$LOG"
        if [ -f /sys/module/lowmemorykiller/parameters/minfree ]; then
            echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*32)),$((RAM*64)),$((RAM*96))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null || echo "Gaming: LMK ไม่รองรับ" >> "$LOG"
        fi
        swapoff /dev/block/zram0 2>/dev/null
        [ -f /sys/block/zram0/disksize ] && echo 0 > /sys/block/zram0/disksize 2>/dev/null
        [ "$NUMA_NODES" -gt 0 ] && echo 0 > /sys/devices/system/node/node0/memlatency 2>/dev/null || echo "Gaming: NUMA memlatency ไม่รองรับ" >> "$LOG"
        ;;
    "performance")
        sysctl -w vm.swappiness=10 2>/dev/null || echo "Performance: ไม่สามารถตั้งค่า swappiness" >> "$LOG"
        sysctl -w vm.vfs_cache_pressure=50 2>/dev/null || echo "Performance: ไม่สามารถตั้งค่า vfs_cache_pressure" >> "$LOG"
        [ -f /sys/module/lowmemorykiller/parameters/minfree ] && echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*36)),$((RAM*55)),$((RAM*73))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
        ;;
    "balanced")
        sysctl -w vm.swappiness=20 2>/dev/null || echo "Balanced: ไม่สามารถตั้งค่า swappiness" >> "$LOG"
        sysctl -w vm.vfs_cache_pressure=75 2>/dev/null || echo "Balanced: ไม่สามารถตั้งค่า vfs_cache_pressure" >> "$LOG"
        [ -f /sys/module/lowmemorykiller/parameters/minfree ] && echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*36)),$((RAM*46)),$((RAM*64))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
        [ "$RAM" -lt 4096 ] && echo $((RAM*256*1024)) > /sys/block/zram0/disksize 2>/dev/null || echo $((RAM*512*1024)) > /sys/block/zram0/disksize 2>/dev/null
        mkswap /dev/block/zram0 2>/dev/null
        swapon /dev/block/zram0 2>/dev/null
        ;;
    "powersave")
        sysctl -w vm.swappiness=60 2>/dev/null || echo "Powersave: ไม่สามารถตั้งค่า swappiness" >> "$LOG"
        sysctl -w vm.vfs_cache_pressure=100 2>/dev/null || echo "Powersave: ไม่สามารถตั้งค่า vfs_cache_pressure" >> "$LOG"
        [ -f /sys/module/lowmemorykiller/parameters/minfree ] && echo "$((RAM*18)),$((RAM*23)),$((RAM*27)),$((RAM*32)),$((RAM*64)),$((RAM*96))" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
        ;;
    "custom")
        if [ -f "/data/gtmodifyplusv1/config/custom.conf" ]; then
            while IFS='=' read -r key value; do
                [ -n "$key" ] && [ -n "$value" ] && echo "$value" > "$key" 2>/dev/null || echo "Custom: ไม่สามารถนำไปใช้ $key=$value" >> "$LOG"
            done < "/data/gtmodifyplusv1/config/custom.conf"
        fi
        ;;
esac
